//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MCCMSG_TestBed.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MCCMSG_TESTBED_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDC_CREATE                      1001
#define IDC_DESTROY                     1002
#define IDC_SELECTDEVICE                1004
#define IDC_PRIMARYSIGNAL               1005
#define IDC_SCAN                        1006
#define IDC_MODEL                       1007
#define IDC_SERIALNUM                   1008
#define IDC_COMPORTID                   1009
#define IDC_DEVICEID                    1010
#define IDC_CHANNELID                   1011
#define IDC_PIPETTEOFFSET               1012
#define IDC_ZAP                         1013
#define IDC_FASTCOMP_AUTO               1014
#define IDC_BTN_VCLAMP                  1015
#define IDC_BTN_ICLAMP                  1016
#define IDC_BTN_ICLAMPZERO              1017
#define IDC_SLOWCOMP_AUTO               1018
#define IDC_SECONDARYSIGNAL             1019
#define IDC_PIPETTEOFFSETVALUE          1020
#define IDC_FASTCOMP_CAP                1021
#define IDC_SLOWCOMP_CAP                1022
#define IDC_PIPETTEOFFSETVALUE_SPINNER  1023
#define IDC_DEVICESTATUS                1024
#define IDC_ZAPDURATION                 1025
#define IDC_SLOWCOMP_TAU                1026
#define IDC_FASTCOMP_TAU                1027
#define IDC_FASTCOMP_CAP_SPINNER        1028
#define IDC_SLOWCOMP_CAP_SPINNER        1029
#define IDC_SLOWCOMP_TAU_SPINNER        1030
#define IDC_PRIMARYGAIN                 1031
#define IDC_FASTCOMP_TAU_SPINNER        1032
#define IDC_PRIMARYLPF                  1033
#define IDC_SECONDARYGAIN               1034
#define IDC_SECONDARYLPF                1035
#define IDC_PRIMARYHPF                  1036
#define IDC_METERRESIST                 1037
#define IDC_METERIRMS                   1038
#define IDC_INJSLOWCURRENTLEVEL         1039
#define IDC_INJSLOWCURRENTLEVEL_SPINNER 1040
#define IDC_BRIDGEBAL_AUTO              1041
#define IDC_BRIDGEBAL_ENBL              1042
#define IDC_METER1                      1043
#define IDC_METER1_VALUE                1044

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1043
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
