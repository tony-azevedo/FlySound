//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MCTeleClient.rc
//
#define IDD_MCTELECLIENT_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDC_SERIALNUM                   1001
#define IDC_CHANNEL                     1002
#define IDC_MODE                        1003
#define IDC_SIGNAL_PRI                  1004
#define IDC_ALPHA_PRI                   1005
#define IDC_SCALEFACTOR_PRI             1006
#define IDC_LPFCUTOFF_PRI               1007
#define IDC_CONNECT                     1008
#define IDC_MEMBRANECAP                 1009
#define IDC_EXTCMDSENS                  1010
#define IDC_REQUEST                     1011
#define IDC_SCALEFACTOR_SEC             1012
#define IDC_BROADCAST                   1013
#define IDC_DEVICELIST                  1014
#define IDC_SIGNAL_SEC                  1015
#define IDC_SCAN                        1016
#define IDC_LPFCUTOFF_SEC               1017
#define IDC_ALPHA_SEC                   1019
#define IDC_APPVER                      1020
#define IDC_FIRMVER                     1021
#define IDC_DSPVER                      1022
#define IDC_SN                          1023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
